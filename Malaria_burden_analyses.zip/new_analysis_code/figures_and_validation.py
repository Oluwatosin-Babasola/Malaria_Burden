import pandas as pd, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = "/tmp/newout"
psa = pd.read_csv(f"{OUT}/psa_draws.csv")
base_pct = 15.14  # manuscript Table 3

# ---- Figure: PSA ----
INK = "#1b2a4a"; ACC = "#3b7dd8"; ACC2 = "#e08a2b"; GRID = "#e6e9ef"
fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))

lo, hi = np.percentile(psa.pct_integrated, [2.5, 97.5])
ax[0].hist(psa.pct_integrated, bins=28, color=ACC, edgecolor="white", alpha=0.9)
ax[0].axvspan(lo, hi, color=ACC, alpha=0.10, label=f"95% interval [{lo:.1f}, {hi:.1f}]")
ax[0].axvline(psa.pct_integrated.mean(), color=INK, lw=2, label=f"Mean {psa.pct_integrated.mean():.2f}%")
ax[0].axvline(base_pct, color=ACC2, lw=2, ls="--", label=f"Base case {base_pct:.2f}%")
ax[0].set_xlabel("Percent reduction in total burden (integrated)")
ax[0].set_ylabel("Number of Monte Carlo draws")
ax[0].set_title("A. Distribution of integrated-strategy performance\n(500 probabilistic draws)", fontsize=11, loc="left")
ax[0].legend(frameon=False, fontsize=8.5)
for s in ["top", "right"]:
    ax[0].spines[s].set_visible(False)

# Panel B: burden averted by strategy across draws
data = [psa.averted_integrated/1e3, psa.averted_proportional/1e3,
        psa.averted_malaria_only/1e3, psa.averted_ntd_only/1e3]
labels = ["Integrated", "Proportional", "Malaria\nonly", "PC/NTD\nonly"]
colors = [ACC, "#9aa7bd", "#7fb0e6", "#c9d6ea"]
bp = ax[1].boxplot(data, labels=labels, patch_artist=True, widths=0.6,
                   medianprops=dict(color=INK, lw=1.6), showfliers=False)
for patch, c in zip(bp["boxes"], colors):
    patch.set_facecolor(c); patch.set_edgecolor("white")
ax[1].set_ylabel("Burden averted (thousand units)")
ax[1].set_title("B. Burden averted by strategy across draws\nintegrated dominant in 100% of draws", fontsize=11, loc="left")
for s in ["top", "right"]:
    ax[1].spines[s].set_visible(False)
ax[1].yaxis.grid(True, color=GRID)
ax[1].set_axisbelow(True)
plt.tight_layout()
plt.savefig(f"{OUT}/figure9_probabilistic_sensitivity.png", dpi=300, bbox_inches="tight")
plt.close()
print("PSA figure saved")

# ---- PSA summary table with dominance probabilities ----
def q(x, p): return float(np.percentile(x, p))
summ = pd.DataFrame([
    {"Quantity": "Percent reduction, integrated (%)", "Mean": psa.pct_integrated.mean(),
     "Median": psa.pct_integrated.median(), "2.5th pct": q(psa.pct_integrated,2.5), "97.5th pct": q(psa.pct_integrated,97.5)},
    {"Quantity": "Burden averted, integrated (units)", "Mean": psa.averted_integrated.mean(),
     "Median": psa.averted_integrated.median(), "2.5th pct": q(psa.averted_integrated,2.5), "97.5th pct": q(psa.averted_integrated,97.5)},
    {"Quantity": "IRS utilisation (%)", "Mean": psa.IRS_pct.mean(), "Median": psa.IRS_pct.median(),
     "2.5th pct": q(psa.IRS_pct,2.5), "97.5th pct": q(psa.IRS_pct,97.5)},
    {"Quantity": "MDA utilisation (%)", "Mean": psa.MDA_pct.mean(), "Median": psa.MDA_pct.median(),
     "2.5th pct": q(psa.MDA_pct,2.5), "97.5th pct": q(psa.MDA_pct,97.5)},
])
summ.to_csv(f"{OUT}/table10_psa_summary.csv", index=False)

dom = pd.DataFrame([
    {"Comparison": "Integrated >= Malaria-only", "Probability": psa.int_gt_malaria.mean()},
    {"Comparison": "Integrated >= PC/NTD-only",  "Probability": psa.int_gt_ntd.mean()},
    {"Comparison": "Integrated >= Proportional", "Probability": psa.int_gt_prop.mean()},
    {"Comparison": "Integrated best of all three","Probability": (psa.int_gt_malaria & psa.int_gt_ntd & psa.int_gt_prop).mean()},
])
dom.to_csv(f"{OUT}/table10b_psa_dominance.csv", index=False)
print(summ.to_string(index=False)); print(); print(dom.to_string(index=False))

# ---- External validation table ----
val = pd.DataFrame([
    {"Quantity": "National Plasmodium falciparum cases (annual)",
     "Model estimate": "72.8 million",
     "Independent benchmark": "68.1 million (WHO World Malaria Report 2024)",
     "Assessment": "Within ~7%; same order of magnitude and Nigeria confirmed as highest-burden country"},
    {"Quantity": "Population requiring PC, three NTDs (summed treatments)",
     "Model estimate": "251.5 million treatment-needs (LF 37.5M, SCH 60.5M, STH 153.4M)",
     "Independent benchmark": "~100 million unique persons at risk of >=1 NTD (WHO/ESPEN)",
     "Assessment": "Consistent: ~2.5 treatments per at-risk person given co-endemicity across the three diseases"},
    {"Quantity": "Highest malaria-burden states (top of ranking)",
     "Model estimate": "Kano, Katsina, Bauchi, Jigawa, Kaduna, Lagos",
     "Independent benchmark": "Known high-transmission northern states + populous Lagos (MAP, NMEP)",
     "Assessment": "Ranking reproduces established subnational epidemiology"},
    {"Quantity": "Burden-unit scale vs full GBD DALYs",
     "Model estimate": "0.801M malaria burden units",
     "Independent benchmark": "GBD malaria DALYs for Nigeria are on the order of tens of millions",
     "Assessment": "Intentionally rescaled reduced-form metric; absolute level is not a GBD DALY estimate"},
])
val.to_csv(f"{OUT}/table11_external_validation.csv", index=False)
print("\nValidation table saved")
