"""Faithful rebuild of the FastAllocationModel from the paper, driven by the
staged table2 baseline. Verifies base numbers, then supports PSA + validation."""
from __future__ import annotations
import json
import numpy as np
import pandas as pd
from types import SimpleNamespace
from scipy.optimize import minimize

INTERVENTIONS = ["ITN", "IRS", "CM", "MDA"]

BASE_PARAMS = {
    "rho":   {"ITN": 0.42, "IRS": 0.50, "CM": 0.35, "MDA": 0.55},
    "eta":   {"ITN": 0.55, "IRS": 0.45, "CM": 0.50, "MDA": 0.65},
    "alpha": {"ITN": 2.00, "IRS": 2.00, "CM": 2.00, "MDA": 2.00},
    "cost":  {"ITN": 3.20, "IRS": 7.50, "CM": 2.25, "MDA": 0.65},
    "Q":     {"ITN": 42_000_000.0, "IRS": 12_000_000.0, "CM": 65_000_000.0, "MDA": 55_000_000.0},
    "budget": 235_000_000.0,
    "itn_people_per_net": 1.8,
    "irs_people_per_household": 5.0,
    "malaria_burden_coeff": 0.011,
    "lf_burden_coeff": 0.006,
    "sch_burden_coeff": 0.006,
    "sth_burden_coeff": 0.006,
}


class FastAllocationModel:
    def __init__(self, df, params):
        self.df = df.copy().reset_index(drop=True)
        self.params = json.loads(json.dumps(params))
        self.n = len(df)
        self.B_m = self.df["B_malaria"].to_numpy(float)
        self.B_n = self.df["B_ntd"].to_numpy(float)
        self.eligible = np.column_stack([
            self.df["population"].to_numpy(float) / self.params["itn_people_per_net"],
            self.df["population"].to_numpy(float) / self.params["irs_people_per_household"],
            self.df["population"].to_numpy(float),
            self.df["mda_required_total"].to_numpy(float),
        ])
        self.baseline = float(np.sum(self.B_m + self.B_n))

    def response(self, x, k):
        a = self.params["alpha"][k]; e = self.params["eta"][k]
        return (x**a) / (x**a + e**a + 1e-12)

    def response_derivative(self, x, k):
        a = self.params["alpha"][k]; e = self.params["eta"][k]
        D = x**a + e**a + 1e-12
        return a * (x ** (a - 1)) * (e**a) / (D**2)

    def post_burden(self, x):
        X = np.asarray(x).reshape(self.n, 4); rho = self.params["rho"]
        res_m = ((1 - rho["ITN"] * self.response(X[:, 0], "ITN"))
                 * (1 - rho["IRS"] * self.response(X[:, 1], "IRS"))
                 * (1 - rho["CM"] * self.response(X[:, 2], "CM")))
        res_n = 1 - rho["MDA"] * self.response(X[:, 3], "MDA")
        return float(np.sum(self.B_m * res_m + self.B_n * res_n))

    def post_burden_grad_scaled(self, x):
        X = np.asarray(x).reshape(self.n, 4); rho = self.params["rho"]
        fac = np.column_stack([1 - rho[k] * self.response(X[:, j], k) for j, k in enumerate(INTERVENTIONS)])
        post = np.sum(self.B_m * fac[:, 0] * fac[:, 1] * fac[:, 2] + self.B_n * fac[:, 3])
        grad = np.zeros((self.n, 4))
        for j, k in enumerate(["ITN", "IRS", "CM"]):
            other = np.ones(self.n)
            for jj in [0, 1, 2]:
                if jj != j:
                    other *= fac[:, jj]
            grad[:, j] = self.B_m * other * (-rho[k] * self.response_derivative(X[:, j], k))
        grad[:, 3] = self.B_n * (-rho["MDA"] * self.response_derivative(X[:, 3], "MDA"))
        return post / self.baseline, grad.ravel() / self.baseline

    def total_cost(self, x):
        X = np.asarray(x).reshape(self.n, 4); c = self.params["cost"]
        return float(np.sum(c["ITN"] * self.eligible[:, 0] * X[:, 0]
                            + c["IRS"] * self.eligible[:, 1] * X[:, 1]
                            + c["CM"] * self.eligible[:, 2] * X[:, 2]
                            + c["MDA"] * self.eligible[:, 3] * X[:, 3]))

    def commodity_use(self, x):
        X = np.asarray(x).reshape(self.n, 4)
        return np.array([np.sum(self.eligible[:, j] * X[:, j]) for j in range(4)])

    def max_violation(self, x):
        uses = self.commodity_use(x)
        v = [max(0.0, self.total_cost(x) - self.params["budget"])]
        v += [max(0.0, uses[j] - self.params["Q"][k]) for j, k in enumerate(INTERVENTIONS)]
        return float(max(v))

    def feasible_start(self, level=0.02, rng=None, random=False, bounds=None):
        if rng is None:
            rng = np.random.default_rng(123)
        x = rng.uniform(0, 1, self.n * 4) if random else np.full(self.n * 4, level)
        if bounds is not None:
            lo = np.array([b[0] for b in bounds]); hi = np.array([b[1] for b in bounds])
            x = np.clip(x, lo, hi)
        return self.project_feasible(x, bounds=bounds)

    def project_feasible(self, x, bounds=None):
        x = np.asarray(x).copy()
        if bounds is not None:
            lo = np.array([b[0] for b in bounds]); hi = np.array([b[1] for b in bounds])
        else:
            lo = np.zeros_like(x); hi = np.ones_like(x)
        x = np.clip(x, lo, hi)
        for _ in range(30):
            if self.max_violation(x) <= 1e-5:
                break
            base = lo.copy(); var = np.maximum(x - base, 0)
            ratios = [1.0]; base_cost = self.total_cost(base)
            var_cost = self.total_cost(base + var) - base_cost
            if var_cost > 0:
                ratios.append((self.params["budget"] - base_cost) / var_cost)
            base_use = self.commodity_use(base); var_use = self.commodity_use(base + var) - base_use
            for j, k in enumerate(INTERVENTIONS):
                if var_use[j] > 0:
                    ratios.append((self.params["Q"][k] - base_use[j]) / var_use[j])
            scale = max(0.0, min(1.0, *ratios) * 0.99999)
            x = np.clip(base + scale * var, lo, hi)
        return x

    def solve(self, x0=None, bounds=None, lam=1000.0, maxiter=600):
        if bounds is None:
            bounds = [(0, 1)] * (self.n * 4)
        if x0 is None:
            x0 = self.feasible_start(bounds=bounds)
        x0 = self.project_feasible(x0, bounds=bounds)
        lo = np.array([b[0] for b in bounds]); hi = np.array([b[1] for b in bounds])

        def fun_grad(x):
            f, g = self.post_burden_grad_scaled(x)
            Xgrad = np.zeros((self.n, 4)); pen = 0.0; c = self.params["cost"]
            q = self.total_cost(x) / self.params["budget"] - 1
            if q > 0:
                pen += q * q
                for j, k in enumerate(INTERVENTIONS):
                    Xgrad[:, j] += 2 * q * c[k] * self.eligible[:, j] / self.params["budget"]
            uses = self.commodity_use(x)
            for j, k in enumerate(INTERVENTIONS):
                q = uses[j] / self.params["Q"][k] - 1
                if q > 0:
                    pen += q * q
                    Xgrad[:, j] += 2 * q * self.eligible[:, j] / self.params["Q"][k]
            return f + lam * pen, g + lam * Xgrad.ravel()

        res = minimize(lambda z: fun_grad(z)[0], x0, jac=lambda z: fun_grad(z)[1],
                       method="L-BFGS-B", bounds=list(zip(lo, hi)),
                       options={"maxiter": maxiter, "ftol": 1e-12, "gtol": 1e-8})
        x = self.project_feasible(res.x, bounds=bounds)
        success = self.max_violation(x) <= 1e-4
        return SimpleNamespace(x=x, success=success, fun=self.post_burden(x))

    def summary(self, res, strategy):
        post = self.post_burden(res.x); averted = self.baseline - post
        return {"strategy": strategy, "success": res.success, "post_burden": post,
                "burden_averted": averted, "percent_reduction": 100 * averted / self.baseline,
                "cost_used": self.total_cost(res.x), "budget": self.params["budget"],
                "max_constraint_violation": self.max_violation(res.x)}

    def commodity_table(self, res):
        used = self.commodity_use(res.x)
        tab = pd.DataFrame({"intervention": INTERVENTIONS, "used": used,
                            "available": [self.params["Q"][k] for k in INTERVENTIONS]})
        tab["remaining"] = tab["available"] - tab["used"]
        tab["percent_used"] = 100 * tab["used"] / tab["available"]
        return tab


def solve_restricted(model, fixed_cols, xstart=None):
    bounds = []
    for _ in range(model.n):
        for j in range(4):
            bounds.append((0, 0) if j in fixed_cols else (0, 1))
    if xstart is not None:
        X = xstart.reshape(model.n, 4).copy()
        for j in fixed_cols:
            X[:, j] = 0
        xstart = X.ravel()
    return model.solve(x0=xstart, bounds=bounds)


def proportional_allocation(model):
    Bm, Bn = model.B_m, model.B_n
    ms = Bm / Bm.sum(); ns = Bn / Bn.sum()
    X = np.zeros((model.n, 4))
    for j, k in enumerate(["ITN", "IRS", "CM"]):
        X[:, j] = np.minimum(1, (model.params["Q"][k] * ms) / np.maximum(model.eligible[:, j], 1e-12))
    X[:, 3] = np.minimum(1, (model.params["Q"]["MDA"] * ns) / np.maximum(model.eligible[:, 3], 1e-12))
    return model.project_feasible(X.ravel())


if __name__ == "__main__":
    df = pd.read_csv("/mnt/user-data/uploads/revised_nigeria_figures_tables_code_final/"
                     "revised_results_outputs_fast/tables/table2_revised_baseline_by_state.csv")
    m = FastAllocationModel(df, BASE_PARAMS)
    base = m.solve()
    print("baseline          ", round(m.baseline, 2), "(paper 2,310,317.99)")
    print("post              ", round(m.post_burden(base.x), 2), "(paper 1,960,446.60)")
    print("averted           ", round(m.baseline - m.post_burden(base.x), 2), "(paper 349,871.38)")
    print("pct               ", round(100*(m.baseline-m.post_burden(base.x))/m.baseline, 3), "(paper 15.14)")
    print("cost used         ", round(m.total_cost(base.x), 2), "(paper 234,997,030.56)")
    print(m.commodity_table(base).to_string(index=False))
    mal = solve_restricted(m, [3], base.x)
    ntd = solve_restricted(m, [0, 1, 2], base.x)
    xp = proportional_allocation(m)
    print("\nStrategy comparison")
    for r in [m.summary(base, "Integrated"), m.summary(mal, "Malaria only"),
              m.summary(ntd, "PC/NTD only"),
              {"strategy": "Proportional", "burden_averted": m.baseline - m.post_burden(xp),
               "percent_reduction": 100*(m.baseline-m.post_burden(xp))/m.baseline}]:
        print(f"  {r['strategy']:14s} averted={r['burden_averted']:.2f} pct={r['percent_reduction']:.3f}")
