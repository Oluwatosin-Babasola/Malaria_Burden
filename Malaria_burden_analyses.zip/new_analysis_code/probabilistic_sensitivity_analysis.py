"""Probabilistic sensitivity analysis (Monte Carlo) over uncertain inputs.
Draws each uncertain parameter from Uniform(0.8,1.2)x base (matching the one-way
+/-20% envelope), re-optimises integrated + comparator strategies each draw, and
summarises the distribution of burden averted and the probability the integrated
strategy dominates each comparator."""
import json, numpy as np, pandas as pd
from model_core import (FastAllocationModel, BASE_PARAMS, INTERVENTIONS,
                        solve_restricted, proportional_allocation)

BASE = "/mnt/user-data/uploads/revised_nigeria_figures_tables_code_final/revised_results_outputs_fast/tables/table2_revised_baseline_by_state.csv"
OUT = "/tmp/newout"
import os; os.makedirs(OUT, exist_ok=True)
df0 = pd.read_csv(BASE)

def rebuild_df(df, p):
    out = df.copy()
    out["B_malaria"] = out["malaria_cases"] * p["malaria_burden_coeff"]
    out["B_lf"]  = out["lf_pop_req"]  * p["lf_burden_coeff"]
    out["B_sch"] = out["sch_pop_req"] * p["sch_burden_coeff"]
    out["B_sth"] = out["sth_pop_req"] * p["sth_burden_coeff"]
    out["B_ntd"] = out["B_lf"] + out["B_sch"] + out["B_sth"]
    return out

N = 500
rng = np.random.default_rng(20260729)
# warm start from base integrated solution
m0 = FastAllocationModel(df0, BASE_PARAMS)
warm = m0.solve().x

rows = []
for i in range(N):
    p = json.loads(json.dumps(BASE_PARAMS))
    f = lambda: float(rng.uniform(0.8, 1.2))
    for k in INTERVENTIONS:
        p["rho"][k]  = min(0.95, BASE_PARAMS["rho"][k] * f())
        p["eta"][k]  = BASE_PARAMS["eta"][k] * f()
        p["cost"][k] = BASE_PARAMS["cost"][k] * f()
        p["Q"][k]    = BASE_PARAMS["Q"][k] * f()
    p["budget"] = BASE_PARAMS["budget"] * f()
    for c in ["malaria_burden_coeff", "lf_burden_coeff", "sch_burden_coeff", "sth_burden_coeff"]:
        p[c] = BASE_PARAMS[c] * f()
    dfi = rebuild_df(df0, p)
    m = FastAllocationModel(dfi, p)
    integ = m.solve(x0=warm, maxiter=300)
    mal   = solve_restricted(m, [3], integ.x)
    ntd   = solve_restricted(m, [0, 1, 2], integ.x)
    xp    = proportional_allocation(m)
    a_int = m.baseline - m.post_burden(integ.x)
    a_mal = m.baseline - m.post_burden(mal.x)
    a_ntd = m.baseline - m.post_burden(ntd.x)
    a_prop = m.baseline - m.post_burden(xp)
    uses = m.commodity_use(integ.x)
    rows.append({
        "draw": i + 1, "baseline": m.baseline,
        "averted_integrated": a_int, "pct_integrated": 100 * a_int / m.baseline,
        "averted_malaria_only": a_mal, "averted_ntd_only": a_ntd, "averted_proportional": a_prop,
        "int_gt_malaria": a_int >= a_mal, "int_gt_ntd": a_int >= a_ntd, "int_gt_prop": a_int >= a_prop,
        "IRS_pct": 100 * uses[1] / p["Q"]["IRS"], "MDA_pct": 100 * uses[3] / p["Q"]["MDA"],
        "ITN_pct": 100 * uses[0] / p["Q"]["ITN"], "CM_pct": 100 * uses[2] / p["Q"]["CM"],
    })
    if (i + 1) % 100 == 0:
        print(f"  {i+1}/{N} done")

res = pd.DataFrame(rows)
res.to_csv(f"{OUT}/psa_draws.csv", index=False)

def q(x, p): return float(np.percentile(x, p))
summary = pd.DataFrame([
    {"quantity": "Percent reduction (integrated)", "mean": res.pct_integrated.mean(),
     "median": res.pct_integrated.median(), "p2.5": q(res.pct_integrated, 2.5), "p97.5": q(res.pct_integrated, 97.5)},
    {"quantity": "Burden averted (integrated)", "mean": res.averted_integrated.mean(),
     "median": res.averted_integrated.median(), "p2.5": q(res.averted_integrated, 2.5), "p97.5": q(res.averted_integrated, 97.5)},
    {"quantity": "IRS utilisation (%)", "mean": res.IRS_pct.mean(), "median": res.IRS_pct.median(),
     "p2.5": q(res.IRS_pct, 2.5), "p97.5": q(res.IRS_pct, 97.5)},
    {"quantity": "MDA utilisation (%)", "mean": res.MDA_pct.mean(), "median": res.MDA_pct.median(),
     "p2.5": q(res.MDA_pct, 2.5), "p97.5": q(res.MDA_pct, 97.5)},
])
summary.to_csv(f"{OUT}/psa_summary.csv", index=False)
print(summary.to_string(index=False))
print("\nP(integrated >= malaria-only) = %.3f" % res.int_gt_malaria.mean())
print("P(integrated >= PC/NTD-only)  = %.3f" % res.int_gt_ntd.mean())
print("P(integrated >= proportional) = %.3f" % res.int_gt_prop.mean())
print("P(integrated best of all)     = %.3f" % (res.int_gt_malaria & res.int_gt_ntd & res.int_gt_prop).mean())
print("IRS >=99%% in %.1f%% of draws; MDA >=99%% in %.1f%% of draws"
      % (100*(res.IRS_pct>=99).mean(), 100*(res.MDA_pct>=99).mean()))
