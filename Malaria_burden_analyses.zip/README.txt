Supplementary materials for the revised manuscript
"Optimal allocation of malaria control and preventive chemotherapy interventions
under resource constraints in Nigeria: a scenario-based constrained optimization model"

new_analysis_code/
  allocation_model_rebuild.py          Faithful rebuild of the constrained-optimization model
                                        (L-BFGS-B penalty solver) driven by the baseline table.
  probabilistic_sensitivity_analysis.py 500-draw Monte Carlo PSA over all uncertain inputs.
  figures_and_validation.py            Generates the PSA figure and external-validation table.

new_result_tables/
  psa_draws_500.csv                    Full 500-draw PSA output (per-draw results).
  psa_summary.csv                      PSA summary (mean, median, 95% interval).
  psa_dominance_probabilities.csv      P(integrated dominates each comparator) = 1.00 for all.
  external_validation.csv              Benchmarking of model inputs vs WHO / UN / ESPEN.

new_figure/
  figure8_probabilistic_sensitivity.png  New Figure 8 (probabilistic sensitivity analysis).

Note on population-weighted incidence: the manuscript describes the actual aggregation used
(zonal mean of MAP raster cells) and flags gridded population-weighting (WorldPop/GRID3) as a
refinement. A population-weighted recompute can be run once a WorldPop Nigeria raster is placed
in the DATA folder.
